import express from 'express';
import { config } from './src/server/config.js';
import { initDb } from './src/server/db.js';
import { createRouter } from './src/server/routes.js';

const app = express();

// Middleware
app.use(express.json());
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', config.corsOrigin);
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

// Initialize database and routes
try {
  const db = await initDb();
  app.use('/api', createRouter(db));

  app.listen(config.port, () => {
    console.log(`Server running at http://localhost:${config.port}`);
  });
} catch (err) {
  console.error('Failed to start server:', err);
  process.exit(1);
}