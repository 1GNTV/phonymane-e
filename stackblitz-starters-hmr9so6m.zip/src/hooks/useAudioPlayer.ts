import { useState, useEffect, useRef } from 'react';
import ReactPlayer from 'react-player';
import { Track } from '../types/track';
import { destroyAudioContext } from '../utils/audioContext';

export const useAudioPlayer = (
  currentTrack: number,
  tracks: Track[],
  isPlaying: boolean,
  setCurrentTrack: (track: number) => void
) => {
  const playerRef = useRef<ReactPlayer>(null);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [seeking, setSeeking] = useState(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (audioElement) {
      audioElement.pause();
      audioElement.src = '';
      destroyAudioContext();
    }

    const audio = new Audio(tracks[currentTrack].audioUrl);
    audio.volume = volume;
    setAudioElement(audio);

    return () => {
      audio.pause();
      audio.src = '';
      destroyAudioContext();
    };
  }, [currentTrack, tracks, volume]);

  const handleProgress = (state: { played: number }) => {
    if (!seeking) {
      setProgress(state.played);
    }
  };

  const handleSeek = {
    onMouseDown: () => setSeeking(true),
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => setProgress(parseFloat(e.target.value)),
    onMouseUp: (e: React.ChangeEvent<HTMLInputElement>) => {
      setSeeking(false);
      if (playerRef.current) {
        playerRef.current.seekTo(parseFloat(e.target.value));
      }
    }
  };

  const handleTrackChange = {
    prev: () => setCurrentTrack(currentTrack === 0 ? tracks.length - 1 : currentTrack - 1),
    next: () => setCurrentTrack(currentTrack === tracks.length - 1 ? 0 : currentTrack + 1)
  };

  const handleVolume = {
    change: (e: React.ChangeEvent<HTMLInputElement>) => {
      const newVolume = parseFloat(e.target.value);
      setVolume(newVolume);
      if (playerRef.current) {
        playerRef.current.player.player.volume = newVolume;
      }
      if (audioElement) {
        audioElement.volume = newVolume;
      }
    },
    toggleMute: () => {
      setIsMuted(!isMuted);
      if (playerRef.current) {
        playerRef.current.player.player.volume = !isMuted ? 0 : volume;
      }
      if (audioElement) {
        audioElement.volume = !isMuted ? 0 : volume;
      }
    }
  };

  return {
    playerRef,
    audioElement,
    volume,
    isMuted,
    progress,
    handleProgress,
    handleSeek,
    handleTrackChange,
    handleVolume
  };
};