export interface Track {
  title: string;
  artist: string;
  duration: string;
  cover: string;
  audioUrl: string;
}

export const tracks: Track[] = [
  {
    title: "SHIZUKA",
    artist: "PHONYMANE",
    duration: "2:45",
    cover: "https://i.ibb.co/NZggkFg/SHIZUKA-min.png",
    audioUrl: "https://audio.jukehost.co.uk/tqRTpFD3I4awI2gWVod8mGtH986dYYUB"
  },
  {
    title: "Project Rally",
    artist: "ANGXL, PHONYMANE",
    duration: "1:45",
    cover: "https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/69/9c/77/699c7728-babd-5257-a9f2-a2c79ebc000a/artwork.jpg/600x600bf-60.jpg",
    audioUrl: "https://audio.jukehost.co.uk/Tj4T1haUzknsroSggYLaLCMgKn9COZiR"
  },
  {
    title: "ON FIRE",
    artist: "PHONYMANE, ZYNYX",
    duration: "4:20",
    cover: "https://i1.sndcdn.com/artworks-CzKz5wxl6LsK7ng3-y8EHBA-t500x500.jpg",
    audioUrl: "https://audio.jukehost.co.uk/sMJt5fGkGkwLH0Vj0gHAmeNYz4hcEjD8"
  },
  {
    title: "DESTINATION",
    artist: "PHONYMANE",
    duration: "2:28",
    cover: "https://i1.sndcdn.com/artworks-8SZpuQKC3yQ4iYSs-y53hjQ-t500x500.jpg",
    audioUrl: "https://audio.jukehost.co.uk/CWh98c1WygxBS3AuqizkheefhWtoNHqk"
  },
  {
    title: "DELTA CLUB",
    artist: "PHONYMANE",
    duration: "3:15",
    cover: "https://i1.sndcdn.com/artworks-YrAMj6kHd9W3yQOr-YcCyzA-t500x500.jpg",
    audioUrl: "https://audio.jukehost.co.uk/hb9eYPhRO0qTiIBekzkNDXqT4NX4kfxY"
  },
  {
    title: "FORD ESCORT",
    artist: "PHONYMANE, DXCD77",
    duration: "2:55",
    cover: "https://i1.sndcdn.com/artworks-0Bv5WcR5l7OPs9D7-aoqFGA-t500x500.jpg",
    audioUrl: "https://audio.jukehost.co.uk/7mWRlnkbMZyePVIlVnEs3KpM1dAXLSso"
  },
  {
    title: "GROUP A",
    artist: "ANGXL, PHONYMANE",
    duration: "3:30",
    cover: "https://e-cdn-images.dzcdn.net/images/cover/35c7db28c4caf35bed886a9f5d81fb73/500x500-000000-80-0-0.jpg",
    audioUrl: "https://audio.jukehost.co.uk/jc7Mt3GLXLcqnso6GFmp5Xc8PdvoHYDh"
  },
  {
    title: "MINDWAVE",
    artist: "PHONYMANE",
    duration: "4:10",
    cover: "https://e-cdn-images.dzcdn.net/images/cover/fe3027421723894583db116a9ec1c852/500x500-000000-80-0-0.jpg",
    audioUrl: "https://audio.jukehost.co.uk/JehzWmjMuhn486ghIQBrQsd2LERq3mIp"
  },
  {
    title: "Nostalgic Feeling",
    artist: "gabriawll, PHONYMANE",
    duration: "3:45",
    cover: "https://e-cdn-images.dzcdn.net/images/cover/61eb81425a0291cceb2e63d4fde504fd/500x500-000000-80-0-0.jpg",
    audioUrl: "https://audio.jukehost.co.uk/ZL99ZSzgIMqXskDhtYzRTH5HJ8gNqxcC"
  },
  {
    title: "SAFARI 1985",
    artist: "PHONYMANE, DXCD77",
    duration: "3:20",
    cover: "https://e-cdn-images.dzcdn.net/images/cover/70d47b1e574b67bda4d567fac1ba5890/500x500-000000-80-0-0.jpg",
    audioUrl: "https://audio.jukehost.co.uk/HFNfBZJsPiruK9MeLtsZKReujUsxj8IE"
  },
  {
    title: "HEAVEN",
    artist: "Astairee, PHONYMANE",
    duration: "4:00",
    cover: "https://e-cdn-images.dzcdn.net/images/cover/97212a90c8867ceba04c73f0164f5dfb/500x500-000000-80-0-0.jpg",
    audioUrl: "https://audio.jukehost.co.uk/6NO9OgA7jYSJdaNLCLywLPlLMCFqBsOI"
  }
];