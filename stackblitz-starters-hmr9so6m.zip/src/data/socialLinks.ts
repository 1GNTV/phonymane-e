export interface SocialLink {
  name: string;
  url: string;
  iconPath: string;
  color: string;
}

export const socialLinks: SocialLink[] = [
  {
    name: "Apple Music",
    url: "https://music.apple.com/us/artist/phonymane/1636986012",
    iconPath: "/icons/apple-music.png",
    color: "hover:bg-gradient-to-r from-pink-600 to-pink-500"
  },
  {
    name: "Instagram",
    url: "https://instagram.com/phonymane_",
    iconPath: "/icons/instagram.png",
    color: "hover:bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500"
  },
  {
    name: "TikTok",
    url: "https://tiktok.com/@phonymane",
    iconPath: "/icons/tiktok.png",
    color: "hover:bg-gradient-to-r from-pink-500 via-red-500 to-purple-500"
  },
  {
    name: "YouTube",
    url: "https://youtube.com/@phonymane",
    iconPath: "/icons/youtube.png",
    color: "hover:bg-gradient-to-r from-red-600 to-red-500"
  },
  {
    name: "Spotify",
    url: "https://open.spotify.com/intl-fr/artist/70n5roMRXP8gDC3gKy8V6A?si=a7_T-2dVS3mt9XRFeIq1Jg",
    iconPath: "/icons/spotify.png",
    color: "hover:bg-gradient-to-r from-green-500 to-green-400"
  },
  {
    name: "SoundCloud",
    url: "https://soundcloud.com/user-824701430",
    iconPath: "/icons/soundcloud.png",
    color: "hover:bg-gradient-to-r from-orange-500 to-orange-400"
  }
];