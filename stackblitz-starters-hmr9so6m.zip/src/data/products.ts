export interface Product {
  id: string;
  name: string;
  description: string;
  price: number | 'FREE';
  image: string;
  downloadUrl: string;
  category: 'drumkit' | 'preset' | 'sample-pack';
  releaseDate: string;
}

export const products: Product[] = [
  {
    id: 'rally-house-drumkit',
    name: '[P] RALLY HOUSE / GARAGE PHONK DRUMKIT',
    description: 'Im PHONYMANE, the first french person to make Rally house, all the way back in January 2024. Since I got some experience in the genre...',
    price: 'FREE',
    image: 'https://public-files.gumroad.com/arn5064gj1em9udss06w8fgxlgyx',
    downloadUrl: 'https://phonymane.gumroad.com/l/RALLY_DRUM_KIT',
    category: 'drumkit',
    releaseDate: '2023-11-01'
  }
];