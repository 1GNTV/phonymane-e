import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export const createRouter = (db) => {
  const router = express.Router();

  // Authentication middleware
  const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ error: 'Invalid token' });
      }
      req.user = user;
      next();
    });
  };

  // Editor authentication
  router.post('/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      const editor = await db.get('SELECT * FROM editors WHERE username = ?', username);

      if (!editor || !(await bcrypt.compare(password, editor.password_hash))) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '24h' });
      res.json({ token });
    } catch (err) {
      console.error('Login error:', err);
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  // Get wiki page content
  router.get('/wiki/:pageKey', async (req, res) => {
    try {
      const { pageKey } = req.params;
      
      const page = await db.get(
        'SELECT * FROM wiki_pages WHERE key = ?',
        pageKey
      );

      if (!page) {
        return res.status(404).json({ error: 'Page not found' });
      }

      res.json({
        title: page.title,
        content: page.content,
        lastModified: page.last_modified,
        editor: page.editor,
        revisionNote: page.revision_note
      });
    } catch (err) {
      console.error('Error fetching wiki content:', err);
      res.status(500).json({ error: 'Failed to fetch content' });
    }
  });

  // Update wiki page content
  router.post('/wiki/:pageKey', authenticateToken, async (req, res) => {
    try {
      const { pageKey } = req.params;
      const { content, revisionNote } = req.body;
      const editor = req.user.username;

      await db.run(
        `INSERT INTO wiki_revisions (page_key, content, editor, revision_note)
         VALUES (?, ?, ?, ?)`,
        pageKey,
        content,
        editor,
        revisionNote
      );

      await db.run(
        `UPDATE wiki_pages 
         SET content = ?, editor = ?, revision_note = ?, last_modified = CURRENT_TIMESTAMP
         WHERE key = ?`,
        content,
        editor,
        revisionNote,
        pageKey
      );

      const updatedPage = await db.get('SELECT * FROM wiki_pages WHERE key = ?', pageKey);
      res.json({
        title: updatedPage.title,
        content: updatedPage.content,
        lastModified: updatedPage.last_modified,
        editor: updatedPage.editor,
        revisionNote: updatedPage.revision_note
      });
    } catch (err) {
      console.error('Error saving wiki content:', err);
      res.status(500).json({ error: 'Failed to save content' });
    }
  });

  // Get page revision history
  router.get('/wiki/:pageKey/history', async (req, res) => {
    try {
      const { pageKey } = req.params;
      const revisions = await db.all(
        `SELECT * FROM wiki_revisions 
         WHERE page_key = ? 
         ORDER BY created_at DESC`,
        pageKey
      );
      res.json(revisions);
    } catch (err) {
      console.error('Error fetching revision history:', err);
      res.status(500).json({ error: 'Failed to fetch revision history' });
    }
  });

  return router;
};