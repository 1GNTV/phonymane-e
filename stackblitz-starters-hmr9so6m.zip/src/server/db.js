import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { config } from './config.js';
import { defaultPages } from './data/defaultContent.js';
import bcrypt from 'bcrypt';

export const initDb = async () => {
  const db = await open({
    filename: config.dbPath,
    driver: sqlite3.Database
  });

  // Create tables
  await db.exec(`
    CREATE TABLE IF NOT EXISTS wiki_pages (
      key TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      last_modified DATETIME DEFAULT CURRENT_TIMESTAMP,
      editor TEXT,
      revision_note TEXT
    );

    CREATE TABLE IF NOT EXISTS wiki_revisions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      page_key TEXT NOT NULL,
      content TEXT NOT NULL,
      editor TEXT NOT NULL,
      revision_note TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (page_key) REFERENCES wiki_pages(key)
    );

    CREATE TABLE IF NOT EXISTS editors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Insert default wiki pages if they don't exist
  for (const page of defaultPages) {
    const existing = await db.get('SELECT 1 FROM wiki_pages WHERE key = ?', page.key);
    if (!existing) {
      await db.run(
        'INSERT INTO wiki_pages (key, title, content, editor) VALUES (?, ?, ?, ?)',
        page.key,
        page.title,
        page.content,
        'system'
      );
    }
  }

  // Create default editor account if not exists
  const defaultEditor = await db.get('SELECT 1 FROM editors WHERE username = ?', 'phonymane');
  if (!defaultEditor) {
    const passwordHash = await bcrypt.hash('phonymane2024', 10);
    await db.run(
      'INSERT INTO editors (username, password_hash) VALUES (?, ?)',
      'phonymane',
      passwordHash
    );
  }

  return db;
};