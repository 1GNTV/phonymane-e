import { RefObject } from 'react';

interface AudioContextManager {
  context: AudioContext;
  analyzer: AnalyserNode;
  source: MediaElementAudioSourceNode;
  dataArray: Uint8Array;
}

let audioContextManager: AudioContextManager | null = null;

export const createAudioContext = (audioElement: HTMLMediaElement): AudioContextManager | null => {
  try {
    // Clean up existing context before creating a new one
    destroyAudioContext();

    // Create new audio context
    const context = new (window.AudioContext || (window as any).webkitAudioContext)();
    const analyzer = context.createAnalyser();
    analyzer.fftSize = 256;

    const source = context.createMediaElementSource(audioElement);
    source.connect(analyzer);
    analyzer.connect(context.destination);

    const dataArray = new Uint8Array(analyzer.frequencyBinCount);

    audioContextManager = {
      context,
      analyzer,
      source,
      dataArray
    };

    return audioContextManager;
  } catch (error) {
    console.error('Failed to create audio context:', error);
    return null;
  }
};

export const destroyAudioContext = () => {
  if (audioContextManager) {
    try {
      audioContextManager.source.disconnect();
      audioContextManager.analyzer.disconnect();
      audioContextManager.context.close();
    } catch (error) {
      console.error('Error cleaning up audio context:', error);
    }
    audioContextManager = null;
  }
};

export const getAudioData = (canvasRef: RefObject<HTMLCanvasElement>) => {
  if (!audioContextManager || !canvasRef.current) return null;

  const canvas = canvasRef.current;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  audioContextManager.analyzer.getByteFrequencyData(audioContextManager.dataArray);
  
  return {
    canvas,
    ctx,
    dataArray: audioContextManager.dataArray
  };
};