import React from 'react';
import { Mail } from 'lucide-react';

interface EmailButtonProps {
  label: string;
  address: string;
}

const EmailButton: React.FC<EmailButtonProps> = ({ label, address }) => {
  return (
    <a
      href={`mailto:${address}`}
      className="w-full px-6 py-4 rounded-lg
        bg-light-void flex items-center gap-4
        transition-all duration-300 transform
        hover:scale-[1.02] hover:bg-blue-600
        hover:text-white"
    >
      <Mail size={24} />
      <div className="flex flex-col">
        <span className="font-medium">{label}</span>
        <span className="text-sm text-blue-steel">{address}</span>
      </div>
    </a>
  );
};

export default EmailButton;