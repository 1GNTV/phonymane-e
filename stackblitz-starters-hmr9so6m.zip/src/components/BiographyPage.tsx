import React from 'react';
import { Music, Award, Calendar, MapPin } from 'lucide-react';

const BiographyPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-void to-light-void pt-20">
      <div className="max-w-4xl mx-auto px-4 py-20">
        {/* Biography Content */}
        <div className="mb-12 text-center">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 p-1">
            <div className="w-full h-full rounded-full bg-dark-void overflow-hidden">
              <img 
                src="https://i.ibb.co/C2vkHt0/Frame-135.png" 
                alt="PHONYMANE"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
            PHONYMANE
          </h1>
          <p className="text-blue-steel text-lg">Pushing the boundaries of phonk music since 2020</p>
        </div>

        <div className="bg-dark-void p-8 rounded-lg mb-20">
          <h2 className="text-2xl font-semibold mb-4">Biography</h2>
          <div className="space-y-4 text-blue-steel">
            <p>
PHONYMANE [foʊniˈmeɪn] is a French 16-year-old producer who takes inspiration on Phonk, Jersey club, House music, and more. He did not blow up yet, but a lot of his songs are progressively rising in terms of streams and recognition. His most streamed single is PROJECT RALLY, inspired by Gran Turismo games, and WRC.
            </p>
            <p>
              Drawing inspiration from car culture and electronic music, PHONYMANE has created
              a signature sound that bridges the gap between phonk and modern
              electronic music (especially deep house and uk garage) , inspired by artists like PXRKX, prod.dtm, Dr Gabba, and more...
            </p>
            <p>
              With multiple successful releases and collaborations with artists like ZYNYX,
              ANGXL, DXCD77, Astairee, and gabriawll PHONYMANE continues to evolve and expand his musical horizons,
              delivering new sounds to his audience.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-dark-void p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Music className="text-blue-steel" />
              <h2 className="text-xl font-semibold">Genre</h2>
            </div>
            <p className="text-blue-steel">Phonk, Deep House, Jersey, Rally House</p>
          </div>

          <div className="bg-dark-void p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Award className="text-blue-steel" />
              <h2 className="text-xl font-semibold">Achievements</h2>
            </div>
            <p className="text-blue-steel">
              2M+ Streams on Spotify<br/>
              Pioneer of "Rally House" in France<br/>
              +200k all time listeners
            </p>
          </div>

          <div className="bg-dark-void p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="text-blue-steel" />
              <h2 className="text-xl font-semibold">Active Since</h2>
            </div>
            <p className="text-blue-steel">2021</p>
          </div>

          <div className="bg-dark-void p-6 rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="text-blue-steel" />
              <h2 className="text-xl font-semibold">Based in</h2>
            </div>
            <p className="text-blue-steel">Paris, France</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BiographyPage;