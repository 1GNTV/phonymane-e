import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { scrollToTop } from '../utils/scroll';

interface NavbarProps {
  onLinktreeOpen: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onLinktreeOpen }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const scrollToSection = (id: string) => {
    if (location.pathname !== '/') {
      navigate('/', { state: { scrollTo: id } });
    } else {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsMenuOpen(false);
  };

  const handleLogoClick = () => {
    navigate('/');
    scrollToTop();
  };

  const handleNavigation = (path: string) => {
    navigate(path);
    scrollToTop();
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-b from-dark-void to-transparent">
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <button
            onClick={handleLogoClick}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <img
              src="https://i.ibb.co/W5YKzfd/PHONY-MANE-2.png"
              alt="PHONYMANE"
              className="h-8"
            />
          </button>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 hover:bg-light-void rounded-lg transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => handleNavigation('/')}
              className="hover:text-blue-steel transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => handleNavigation('/biography')}
              className="hover:text-blue-steel transition-colors"
            >
              Biography
            </button>
            <button
              onClick={() => scrollToSection('releases')}
              className="hover:text-blue-steel transition-colors"
            >
              Releases
            </button>
            <button
              onClick={onLinktreeOpen}
              className="hover:text-blue-steel transition-colors"
            >
              Links
            </button>
            <button
              onClick={() => handleNavigation('/contact')}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors"
            >
              Contact
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-dark-void border-t border-blue-steel/20 p-4 space-y-4 animate-fadeIn">
            <button
              onClick={() => {
                handleNavigation('/');
                setIsMenuOpen(false);
              }}
              className="block w-full text-left hover:text-blue-steel transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => {
                handleNavigation('/biography');
                setIsMenuOpen(false);
              }}
              className="block w-full text-left hover:text-blue-steel transition-colors"
            >
              Biography
            </button>
            <button
              onClick={() => scrollToSection('releases')}
              className="block w-full text-left hover:text-blue-steel transition-colors"
            >
              Releases
            </button>
            <button
              onClick={() => {
                onLinktreeOpen();
                setIsMenuOpen(false);
              }}
              className="block w-full text-left hover:text-blue-steel transition-colors"
            >
              Links
            </button>
            <button
              onClick={() => {
                handleNavigation('/contact');
                setIsMenuOpen(false);
              }}
              className="block w-full bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors text-center"
            >
              Contact
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;