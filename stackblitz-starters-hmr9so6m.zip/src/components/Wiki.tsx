import React, { useState } from 'react';
import { Sun, Moon } from 'lucide-react';

const Wiki = () => {
  const [isDarkMode, setIsDarkMode] = useState(true);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <div className={`min-h-screen pt-20 ${isDarkMode ? 'bg-dark-void text-white' : 'bg-white text-dark-void'}`}>
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">PHONYMANE Wiki</h1>
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-lg ${
              isDarkMode ? 'bg-light-void hover:bg-blue-steel/20' : 'bg-gray-100 hover:bg-gray-200'
            } transition-colors`}
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>

        {/* Main Content */}
        <div className={`p-8 rounded-lg ${isDarkMode ? 'bg-light-void' : 'bg-gray-100'}`}>
          <article className={`prose ${isDarkMode ? 'prose-invert' : ''} max-w-none`}>
            <h1>Welcome to PHONYMANE Wiki</h1>
            
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>

            <h2>Section 1</h2>
            <p>
              Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>

            <h2>Section 2</h2>
            <p>
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
            </p>

            <h3>Subsection 2.1</h3>
            <ul>
              <li>Nemo enim ipsam voluptatem quia voluptas</li>
              <li>Sit aspernatur aut odit aut fugit</li>
              <li>Sed quia consequuntur magni dolores</li>
            </ul>

            <h2>Section 3</h2>
            <p>
              At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.
            </p>

            <blockquote>
              Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.
            </blockquote>
          </article>
        </div>
      </div>
    </div>
  );
};

export default Wiki;