import React from 'react';
import { socialLinks } from '../data/socialLinks';
import SocialButton from './SocialButton';
import EmailButton from './EmailButton';

const Shows = () => {
  return (
    <section className="py-20 px-4 md:px-8 bg-gradient-to-b from-dark-void to-light-void">
    </section>
  );
};

export default Shows;