import React from 'react';
import { LucideIcon } from 'lucide-react';

interface SocialButtonProps {
  name: string;
  url: string;
  icon: LucideIcon | React.FC;
  color: string;
}

const SocialButton: React.FC<SocialButtonProps> = ({ name, url, icon: Icon, color }) => {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={`
        w-full px-6 py-4 rounded-lg
        bg-light-void flex items-center gap-4
        transition-all duration-300 transform
        hover:scale-[1.02] ${color}
        hover:text-white
      `}
    >
      {typeof Icon === 'function' && <Icon size={24} />}
      <span className="font-medium">{name}</span>
    </a>
  );
};

export default SocialButton;