// Content for the Rally House wiki page
export const rallyHouseContent = {
  title: 'Rally House',
  content: `# Rally House

Rally House (also known as Rally Phonk or Racing House) is an electronic music subgenre that emerged in the early 2020s, combining elements of phonk, house music, and motorsport culture.

## Origins and Development

Rally House emerged from the intersection of:
- Traditional phonk music, characterized by its Memphis rap influences, chopped samples, and distorted 808s.
- European house music, known for its soulful melodies, rhythmic beats, and piano stabs.
- Motorsport culture and racing games, which provide thematic and auditory inspiration, including car engine samples and fast tempos.

The genre gained traction in car enthusiast communities, racing game soundtracks, and on platforms like TikTok and YouTube. It was popularized by artists like prod.DTM, whose single "Rally House" (January 2024) gave the genre its name.

## Musical Characteristics

### Key Elements
- **Heavy, distorted 808 bass lines** that drive the rhythm.
- **Racing car engine samples** and drifting sound effects.
- **Hard-hitting house drums** with consistent 4/4 beats.
- **Atmospheric pads** and high-energy percussion.
- **Piano-like melodic stabs**, a hallmark of the genre, reminiscent of early house music.

### Tempo and Structure
- Typically ranges from 128-140 BPM.
- Follows a traditional house music structure, including extended build-ups, energetic drops, and repetitive hooks.
- Incorporates racing-themed sound effects to create a sense of motion and excitement.

## Cultural Impact

Rally House has seen rapid growth in:
- **Car Enthusiast Circles**: Frequently used in drift videos and car showcases.
- **Racing Game Communities**: Fan-made soundtracks for games like *Forza Horizon* and *Initial D* often feature Rally House tracks.
- **Social Media**: Platforms like TikTok and YouTube have popularized the genre through short, engaging clips that combine visuals and music.
- **Underground Electronic Scenes**: Embraced by DJs and producers for its energetic vibe and nostalgic nod to early house music.

## Notable Artists

### Pioneers
- **prod.DTM**: Credited with naming and shaping the genre.
- **PHONYMANE**: Blends phonk and house elements with a racing aesthetic.
- **ANGXL**: Known for integrating hardcore and UK garage influences.

### Other Contributors
- **DXCD77**: Brings a melodic touch to the genre.
- **Ricii Lompeurs**: Focuses on high-energy tracks with intricate percussion.
- **Dr. Gabba**: Incorporates retro and racing-inspired sounds.

### Notable Releases
1. "Rally House" by prod.DTM
2. "PROJECT RALLY" by PHONYMANE
3. "FORD ESCORT" by DXCD77
4. "Group A" by ANGXL & PHONYMANE

## Infobox

|   **Attribute**        |   **Details**               |
|------------------------|----------------------------|
| **Stylistic Origins**   | Phonk, House music, Drift Phonk |
| **Cultural Origins**    | Early 2020s, Europe        |
| **Typical Instruments** | Synthesizers, Samplers, Digital Audio Workstations |
| **Derivative Forms**    | None yet (emerging genre) |
| **Subgenres**           | None established          |

Rally House continues to evolve, captivating audiences worldwide with its unique fusion of house beats, phonk basslines, and motorsport aesthetics.`,
  infobox: {
    image: "https://placehold.co/400x300",
    caption: "Visual representation of Rally House music elements",
    details: [
      { label: "Stylistic origins", value: "Phonk, House music, Drift Phonk" },
      { label: "Cultural origins", value: "Early 2020s, Europe" },
      { label: "Typical instruments", value: "Synthesizers, Samplers, Digital Audio Workstations" },
      { label: "Derivative forms", value: "None yet (emerging genre)" },
      { label: "Subgenres", value: "None established" }
    ]
  }
};
