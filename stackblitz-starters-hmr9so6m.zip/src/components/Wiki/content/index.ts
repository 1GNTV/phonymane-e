// Export all wiki content from a single file for easier management
import { phonymaneContent } from './phonymaneContent';
import { rallyHouseContent } from './rallyHouseContent';

export const wikiContent = {
  phonymane: phonymaneContent,
  rallyHouse: rallyHouseContent
};