import axios from 'axios';
import { WikiPage, WikiRevision } from './types';

const API_URL = 'http://localhost:3000/api';

export const login = async (username: string, password: string): Promise<string> => {
  try {
    const response = await axios.post(`${API_URL}/auth/login`, { username, password });
    return response.data.token;
  } catch (error) {
    throw new Error('Authentication failed');
  }
};

export const saveWikiContent = async (
  pageKey: string, 
  content: string,
  revisionNote: string,
  token: string
): Promise<WikiPage> => {
  try {
    const response = await axios.post(
      `${API_URL}/wiki/${pageKey}`,
      { content, revisionNote },
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    return response.data;
  } catch (error) {
    throw new Error('Failed to save wiki content');
  }
};

export const getWikiContent = async (pageKey: string): Promise<WikiPage> => {
  try {
    const response = await axios.get(`${API_URL}/wiki/${pageKey}`);
    return response.data;
  } catch (error) {
    throw new Error('Failed to fetch wiki content');
  }
};

export const getRevisionHistory = async (pageKey: string): Promise<WikiRevision[]> => {
  try {
    const response = await axios.get(`${API_URL}/wiki/${pageKey}/history`);
    return response.data;
  } catch (error) {
    throw new Error('Failed to fetch revision history');
  }
};