import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useWikiContext } from './WikiContext';
import { wikiPages } from './wikiData';
import WikiEditor from './components/WikiEditor';
import { useKeySequence } from './hooks/useKeySequence';
import { useLocation, useNavigate } from 'react-router-dom';
import { saveWikiContent, getWikiContent } from './api';

interface WikiContentProps {
  pageKey: string;
}

const WikiContent: React.FC<WikiContentProps> = ({ pageKey }) => {
  const { isDarkMode } = useWikiContext();
  const [isSecretEditMode, setIsSecretEditMode] = React.useState(false);
  const [isSaving, setIsSaving] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = React.useState(wikiPages[pageKey]);

  React.useEffect(() => {
    if (!location.state?.fromMainPage) {
      navigate('/wiki');
      return;
    }

    const fetchContent = async () => {
      try {
        const content = await getWikiContent(pageKey);
        setCurrentPage(content);
      } catch (err) {
        console.error('Error fetching wiki content:', err);
        setCurrentPage(wikiPages[pageKey]);
      }
    };

    fetchContent();
  }, [location.state, navigate, pageKey]);

  useKeySequence('phonymane', () => {
    setIsSecretEditMode(true);
  });

  const handleSave = async (newContent: string) => {
    setIsSaving(true);
    setError(null);
    
    try {
      const updatedPage = await saveWikiContent(pageKey, newContent);
      setCurrentPage(updatedPage);
      setIsSecretEditMode(false);
    } catch (err) {
      setError('Failed to save changes. Please try again.');
      console.error('Error saving content:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const renderInfoBox = () => (
    <div className="float-right ml-6 mb-6">
      <div className="bg-dark-void rounded-lg p-4 w-80">
        <img
          src={currentPage.infobox.image}
          alt={currentPage.title}
          className="w-full rounded-lg mb-4"
        />
        <p className="text-sm text-center text-blue-steel mb-4">{currentPage.infobox.caption}</p>
        <table className="w-full text-sm">
          <tbody>
            {currentPage.infobox.details.map((detail, index) => (
              <tr key={index} className="border-b border-blue-steel/20 last:border-0">
                <td className="text-blue-steel py-2 pr-4">{detail.label}</td>
                <td className="py-2">{detail.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (!location.state?.fromMainPage) {
    return null;
  }

  return (
    <div className={`bg-light-void rounded-lg p-8 ${isDarkMode ? 'text-white' : 'text-dark-void'}`}>
      <article className={`prose ${isDarkMode ? 'prose-invert' : ''} max-w-none`}>
        {error && (
          <div className="bg-red-500/10 text-red-500 p-4 rounded-lg mb-4">
            {error}
          </div>
        )}
        
        {isSecretEditMode ? (
          <WikiEditor 
            content={currentPage.content} 
            onSave={handleSave}
            isSaving={isSaving} 
          />
        ) : (
          <>
            {renderInfoBox()}
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {currentPage.content}
            </ReactMarkdown>
          </>
        )}
      </article>
    </div>
  );
};

export default WikiContent;