import React from 'react';
import { Routes, Route } from 'react-router-dom';
import WikiSidebar from './components/WikiSidebar';
import WikiContent from './components/WikiContent';
import WikiHeader from './components/WikiHeader';
import WikiTabs from './components/WikiTabs';
import MainPage from './components/MainPage';
import { WikiProvider } from './context/WikiContext';

const Wiki = () => {
  return (
    <div className="min-h-screen pt-20 bg-dark-void text-white">
      <WikiProvider>
        <div className="max-w-[1440px] mx-auto px-4 py-12">
          <div className="flex flex-col md:flex-row gap-6">
            <WikiSidebar />
            <main className="flex-1">
              <WikiHeader />
              <WikiTabs />
              <Routes>
                <Route path="/" element={<MainPage />} />
                <Route path="/phonymane" element={<WikiContent pageKey="phonymane" />} />
                <Route path="/rallyHouse" element={<WikiContent pageKey="rallyHouse" />} />
              </Routes>
            </main>
          </div>
        </div>
      </WikiProvider>
    </div>
  );
};

export default Wiki;