import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Music } from 'lucide-react';

const MainPage = () => {
  const navigate = useNavigate();
  
  const pages = [
    {
      title: 'PHONYMANE',
      description: 'Learn about PHONYMANE, his music, and career.',
      path: '/wiki/phonymane',
      image: 'https://i.ibb.co/C2vkHt0/Frame-135.png'
    },
    {
      title: 'Rally House',
      description: 'Explore the Rally House music genre and its characteristics.',
      path: '/wiki/rallyHouse',
      image: 'https://placehold.co/400x300'
    }
  ];

  const handleNavigation = (path: string) => {
    navigate(path, { state: { fromMainPage: true } });
  };

  return (
    <div className="bg-light-void rounded-lg p-8">
      <h1 className="text-3xl font-bold mb-8">Welcome to PHONYMANE Wiki</h1>
      <p className="text-blue-steel mb-12">
        Explore articles about PHONYMANE and the Rally House genre. Click on any card below to learn more.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {pages.map((page) => (
          <button
            key={page.title}
            onClick={() => handleNavigation(page.path)}
            className="group bg-dark-void rounded-lg p-6 transition-all duration-300 hover:scale-[1.02] w-full text-left hover:bg-blue-steel/20"
          >
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                <img
                  src={page.image}
                  alt={page.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h2 className="text-xl font-semibold mb-2 flex items-center gap-2">
                  <Music size={20} className="text-blue-steel group-hover:text-white transition-colors" />
                  <span className="group-hover:text-white transition-colors">{page.title}</span>
                </h2>
                <p className="text-blue-steel group-hover:text-white/70 transition-colors">{page.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default MainPage;