import React, { createContext, useContext, useState } from 'react';

interface WikiContextType {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  isDarkMode: boolean;
  setIsDarkMode: (isDark: boolean) => void;
  currentLanguage: string;
  setCurrentLanguage: (lang: string) => void;
}

const WikiContext = createContext<WikiContextType | undefined>(undefined);

export const WikiProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTab, setCurrentTab] = useState('read');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  return (
    <WikiContext.Provider value={{
      currentTab,
      setCurrentTab,
      isDarkMode,
      setIsDarkMode,
      currentLanguage,
      setCurrentLanguage
    }}>
      {children}
    </WikiContext.Provider>
  );
};

export const useWikiContext = () => {
  const context = useContext(WikiContext);
  if (context === undefined) {
    throw new Error('useWikiContext must be used within a WikiProvider');
  }
  return context;
};