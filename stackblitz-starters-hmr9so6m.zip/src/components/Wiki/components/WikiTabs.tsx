import React from 'react';
import { FileText, History, Star } from 'lucide-react';
import { useWikiContext } from '../context/WikiContext';
import { useLocation } from 'react-router-dom';
import { scrollToTop } from '../../../utils/scroll';

const WikiTabs = () => {
  const { currentTab, setCurrentTab } = useWikiContext();
  const location = useLocation();

  const tabs = [
    { 
      id: 'read', 
      name: 'Read', 
      icon: FileText,
      enabled: true
    },
    { 
      id: 'history', 
      name: 'History', 
      icon: History,
      enabled: location.pathname !== '/wiki'
    },
    { 
      id: 'favorites', 
      name: 'Favorites', 
      icon: Star,
      enabled: location.pathname !== '/wiki'
    }
  ];

  const handleTabClick = (tabId: string) => {
    if (tabs.find(tab => tab.id === tabId)?.enabled) {
      setCurrentTab(tabId);
      scrollToTop();
    }
  };

  return (
    <div className="flex border-b border-blue-steel/20 mb-6">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => handleTabClick(tab.id)}
          disabled={!tab.enabled}
          className={`
            flex items-center gap-2 px-6 py-3 border-b-2 transition-all duration-300
            ${currentTab === tab.id && tab.enabled
              ? 'border-blue-500 text-blue-500'
              : 'border-transparent'
            }
            ${tab.enabled
              ? 'hover:border-blue-steel/20 hover:text-blue-steel'
              : 'opacity-50 cursor-not-allowed'
            }
          `}
        >
          <tab.icon size={18} />
          <span>{tab.name}</span>
        </button>
      ))}
    </div>
  );
};

export default WikiTabs;