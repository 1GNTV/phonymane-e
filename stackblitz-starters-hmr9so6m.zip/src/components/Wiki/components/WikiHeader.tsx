import React from 'react';
import { Sun, Moon, Globe } from 'lucide-react';
import { useWikiContext } from '../context/WikiContext';

const WikiHeader = () => {
  const { isDarkMode, setIsDarkMode, currentLanguage, setCurrentLanguage } = useWikiContext();

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'fr', name: 'Français' },
    { code: 'es', name: 'Español' },
  ];

  return (
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
        PHONYMANE Wiki
      </h1>
      
      <div className="flex items-center gap-4">
        <div className="relative group">
          <button className="p-2 rounded-lg bg-light-void hover:bg-blue-steel/20 transition-colors flex items-center gap-2">
            <Globe size={20} />
            <span>{languages.find(lang => lang.code === currentLanguage)?.name}</span>
          </button>
          <div className="absolute right-0 top-full mt-2 bg-light-void rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
            {languages.map(lang => (
              <button
                key={lang.code}
                onClick={() => setCurrentLanguage(lang.code)}
                className="block w-full text-left px-4 py-2 hover:bg-blue-steel/20 transition-colors"
              >
                {lang.name}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="p-2 rounded-lg bg-light-void hover:bg-blue-steel/20 transition-colors"
        >
          {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
      </div>
    </div>
  );
};

export default WikiHeader;