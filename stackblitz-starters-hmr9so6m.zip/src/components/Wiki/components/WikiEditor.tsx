import React from 'react';

interface WikiEditorProps {
  content: string;
  onSave: (content: string) => void;
  isSaving: boolean;
}

const WikiEditor: React.FC<WikiEditorProps> = ({ content, onSave, isSaving }) => {
  const [editedContent, setEditedContent] = React.useState(content);

  const handleSave = () => {
    onSave(editedContent);
  };

  return (
    <div className="border border-blue-steel/20 rounded-lg p-4">
      <textarea
        className="w-full h-[500px] bg-dark-void text-white p-4 rounded-lg resize-none focus:outline-none"
        value={editedContent}
        onChange={(e) => setEditedContent(e.target.value)}
        disabled={isSaving}
      />
      <div className="flex justify-end mt-4">
        <button 
          onClick={handleSave}
          disabled={isSaving}
          className={`px-6 py-2 bg-blue-600 rounded-lg transition-colors ${
            isSaving ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'
          }`}
        >
          {isSaving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </div>
  );
};

export default WikiEditor;