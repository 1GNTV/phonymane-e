import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useWikiContext } from '../context/WikiContext';
import { wikiContent } from '../content';
import { useLocation, useNavigate } from 'react-router-dom';

interface WikiContentProps {
  pageKey: string;
}

const WikiContent: React.FC<WikiContentProps> = ({ pageKey }) => {
  const { isDarkMode } = useWikiContext();
  const location = useLocation();
  const navigate = useNavigate();
  const currentPage = wikiContent[pageKey as keyof typeof wikiContent];

  React.useEffect(() => {
    if (!location.state?.fromMainPage) {
      navigate('/wiki');
    }
  }, [location.state, navigate]);

  const renderInfoBox = () => (
    <div className="float-right ml-6 mb-6">
      <div className="bg-dark-void rounded-lg p-4 w-80">
        <img
          src={currentPage.infobox.image}
          alt={currentPage.title}
          className="w-full rounded-lg mb-4"
        />
        <p className="text-sm text-center text-blue-steel mb-4">{currentPage.infobox.caption}</p>
        <table className="w-full text-sm">
          <tbody>
            {currentPage.infobox.details.map((detail, index) => (
              <tr key={index} className="border-b border-blue-steel/20 last:border-0">
                <td className="text-blue-steel py-2 pr-4">{detail.label}</td>
                <td className="py-2">{detail.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (!location.state?.fromMainPage) {
    return null;
  }

  return (
    <div className={`bg-light-void rounded-lg p-8 ${isDarkMode ? 'text-white' : 'text-dark-void'}`}>
      <article className={`prose ${isDarkMode ? 'prose-invert' : ''} max-w-none`}>
        {renderInfoBox()}
        <ReactMarkdown remarkPlugins={[remarkGfm]}>
          {currentPage.content}
        </ReactMarkdown>
      </article>
    </div>
  );
};

export default WikiContent;