export const pages = {
  phonymane: {
    title: 'PHONYMANE',
    path: '/wiki/phonymane',
    content: `# PHONYMANE

PHONYMANE [foʊniˈmeɪn] is a French music producer and DJ, known for his contributions to the phonk and rally house genres. Born in 2007, he began his musical journey in 2020 and has since become a prominent figure in the underground electronic music scene.

## Early Life and Career

PHONYMANE started producing music at the age of 13, initially experimenting with various electronic music genres. His early influences included car culture, racing games, and electronic music producers like PXRKX, prod.dtm, and Dr Gabba. By 2021, he had developed his signature sound, which combines elements of phonk, deep house, and UK garage.

## Musical Style and Influences

PHONYMANE's music is characterized by its unique blend of:

- Heavy bass-driven phonk elements
- Racing-inspired sound design
- Deep house rhythms
- Jersey club influences
- Atmospheric synthwave elements

His production style often incorporates:

1. Hard-hitting 808s
2. Complex drum patterns
3. Atmospheric pads
4. Racing car samples
5. Vintage synthesizer sounds

## Notable Releases

### Singles
- "PROJECT RALLY" (2023)
- "ON FIRE" feat. ZYNYX (2023)
- "SHIZUKA" (2024)

### Collaborations
- "Group A" with ANGXL
- "FORD ESCORT" with DXCD77
- "Nostalgic Feeling" with gabriawll`
  },
  rallyHouse: {
    title: 'Rally House',
    path: '/wiki/rally-house',
    content: `# Rally House

Rally House is an emerging electronic music subgenre that combines elements of phonk, house music, and motorsport culture. The genre gained prominence in the early 2020s, particularly within the European electronic music scene.

## Origins and Development

Rally House emerged from the intersection of:
- Traditional phonk music
- European house music
- Motorsport culture and racing games
- Car enthusiast communities

The genre was pioneered by producers like PHONYMANE, who began incorporating racing-inspired elements into their music around 2023.

## Musical Characteristics

### Key Elements
- Heavy, distorted 808 bass lines
- Racing car engine samples
- Hard-hitting house drums
- Atmospheric synthesizer pads
- High-energy percussion

### Tempo and Structure
- Typically ranges from 128-135 BPM
- House music song structure
- Extended build-ups and drops
- Racing-themed sound effects

## Cultural Impact

Rally House has gained significant traction in:
- Car enthusiast communities
- Racing game soundtracks
- Underground electronic music scenes
- Social media platforms (particularly TikTok)

## Notable Artists

### Pioneers
- PHONYMANE (France)
- ZYNYX
- DXCD77

### Notable Releases
1. "PROJECT RALLY" by PHONYMANE
2. "FORD ESCORT" by PHONYMANE & DXCD77
3. "Group A" by ANGXL & PHONYMANE

## Influence on Modern Music

The genre has influenced:
- Contemporary phonk production
- Racing game soundtracks
- European club music
- Social media music trends

## Future Development

Rally House continues to evolve with:
- New production techniques
- Cross-genre collaborations
- Growing international recognition
- Integration with gaming culture`
  }
};