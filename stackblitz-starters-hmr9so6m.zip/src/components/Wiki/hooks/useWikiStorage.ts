import useLocalStorage from 'use-local-storage';
import { WikiPage } from '../types';

export const useWikiStorage = (pageKey: string, initialContent: WikiPage) => {
  const storageKey = `wiki_${pageKey}`;
  const [storedContent, setStoredContent] = useLocalStorage<WikiPage>(
    storageKey,
    initialContent
  );

  const updateContent = (newContent: string) => {
    setStoredContent({
      ...storedContent,
      content: newContent
    });
  };

  return {
    content: storedContent,
    updateContent
  };
};