import { useState, useEffect } from 'react';

export const useKeySequence = (targetSequence: string, callback: () => void) => {
  const [currentSequence, setCurrentSequence] = useState<string>('');

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      const newSequence = (currentSequence + event.key).slice(-targetSequence.length);
      setCurrentSequence(newSequence);

      if (newSequence.toLowerCase() === targetSequence.toLowerCase()) {
        callback();
        setCurrentSequence('');
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentSequence, targetSequence, callback]);
};