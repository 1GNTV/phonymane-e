export interface InfoBoxDetail {
  label: string;
  value: string;
}

export interface InfoBox {
  image: string;
  caption: string;
  details: InfoBoxDetail[];
}

export interface WikiPage {
  title: string;
  path: string;
  content: string;
  infobox: InfoBox;
  lastModified?: string;
  editor?: string;
  revisionNote?: string;
}

export interface WikiRevision {
  id: number;
  page_key: string;
  content: string;
  editor: string;
  revision_note: string;
  created_at: string;
}

export interface EditorCredentials {
  username: string;
  password: string;
}