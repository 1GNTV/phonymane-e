import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Music } from 'lucide-react';

const WikiSidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const navigation = [
    { name: 'Main Page', icon: Home, path: '/wiki' },
    { 
      name: 'PHONYMANE', 
      icon: Music, 
      path: '/wiki/phonymane',
      requiresMainPage: true 
    },
    { 
      name: 'Rally House', 
      icon: Music, 
      path: '/wiki/rallyHouse',
      requiresMainPage: true 
    },
  ];

  const handleNavigation = (path: string) => {
    const item = navigation.find(nav => nav.path === path);
    if (item?.requiresMainPage && !location.state?.fromMainPage) {
      navigate('/wiki');
      return;
    }
    navigate(path);
  };

  const isDisabled = (item: typeof navigation[0]) => {
    return item.requiresMainPage && !location.state?.fromMainPage;
  };

  return (
    <aside className="w-64 shrink-0 hidden md:block space-y-4">
      <div className="bg-light-void rounded-lg p-4">
        <img 
          src="https://i.ibb.co/C2vkHt0/Frame-135.png"
          alt="PHONYMANE Logo"
          className="w-32 h-32 mx-auto mb-4 rounded-full"
        />
        <nav className="space-y-2">
          {navigation.map((item) => (
            <button
              key={item.name}
              onClick={() => handleNavigation(item.path)}
              disabled={isDisabled(item)}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
                location.pathname === item.path 
                  ? 'bg-blue-steel/20 text-white' 
                  : isDisabled(item)
                  ? 'opacity-50 cursor-not-allowed text-blue-steel'
                  : 'text-blue-steel hover:bg-blue-steel/20 hover:text-white'
              }`}
            >
              <item.icon size={18} className={location.pathname === item.path ? 'text-white' : 'text-blue-steel'} />
              <span>{item.name}</span>
            </button>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default WikiSidebar;