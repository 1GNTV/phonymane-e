import React from 'react';
import { X } from 'lucide-react';
import { socialLinks } from '../data/socialLinks';
import SocialButton from './SocialButton';
import EmailButton from './EmailButton';

interface LinktreeProps {
  isOpen: boolean;
  onClose: () => void;
}

const Linktree: React.FC<LinktreeProps> = ({ isOpen, onClose }) => {
  const emails = [
    { address: 'demo@phonymane.fr', label: 'Demo' },
    { address: 'contact@phonymane.fr', label: 'Contact' },
    { address: 'management@phonymane.fr', label: 'Management' }
  ];

  React.useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="min-h-screen px-4 text-center">
        {/* Background overlay */}
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm animate-fadeIn" onClick={onClose} />
        
        {/* Modal container */}
        <div className="inline-block w-full max-w-2xl my-8 text-left align-middle transition-all transform">
          <div className="relative bg-dark-void rounded-2xl shadow-2xl p-8 animate-scaleIn">
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 hover:bg-light-void rounded-full transition-colors"
            >
              <X size={24} />
            </button>

            <div className="text-center mb-12">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 p-1">
                <div className="w-full h-full rounded-full bg-dark-void overflow-hidden">
                  <img 
                    src="https://i.ibb.co/C2vkHt0/Frame-135.png" 
                    alt="Logo"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                PHONYMANE
              </h2>
              <p className="text-blue-steel">Find me on all platforms</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
              {socialLinks.map((link, index) => (
                <SocialButton
                  key={index}
                  name={link.name}
                  url={link.url}
                  icon={link.iconPath}
                  color={link.color}
                />
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {emails.map((email, index) => (
                <EmailButton
                  key={index}
                  label={email.label}
                  address={email.address}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Linktree;