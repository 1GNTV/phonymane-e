import React from 'react';
import { Package } from 'lucide-react';
import { products } from '../data/products';

const Products = () => {
  return (
    <section className="py-20 px-4 md:px-8 bg-light-void">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-2xl font-semibold mb-8 flex items-center gap-2">
          <Package className="text-blue-steel" />
          Products
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {products.map((product) => (
            <div key={product.id} className="bg-dark-void rounded-lg overflow-hidden">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full aspect-square object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                <p className="text-blue-steel mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-green-500">FREE</span>
                  <a 
                    href={product.downloadUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-2 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Download Now
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;