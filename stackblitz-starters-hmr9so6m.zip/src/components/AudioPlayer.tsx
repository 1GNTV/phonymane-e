import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, SkipBack, SkipForward, ChevronDown, ChevronUp } from 'lucide-react';
import ReactPlayer from 'react-player';
import { tracks } from '../data/tracks';
import AudioVisualizer from './AudioVisualizer';
import { destroyAudioContext } from '../utils/audioContext';

interface AudioPlayerProps {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  currentTrack: number;
  setCurrentTrack: (track: number) => void;
  isVisualizerEnabled: boolean;
  setIsVisualizerEnabled: (enabled: boolean) => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ 
  isPlaying, 
  setIsPlaying, 
  currentTrack, 
  setCurrentTrack,
  isVisualizerEnabled,
  setIsVisualizerEnabled
}) => {
  const playerRef = useRef<ReactPlayer>(null);
  const [volume, setVolume] = useState(0.5);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [seeking, setSeeking] = useState(false);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    // Cleanup previous audio element and context
    if (audioElement) {
      audioElement.pause();
      audioElement.src = '';
      destroyAudioContext();
    }

    const audio = new Audio(tracks[currentTrack].audioUrl);
    audio.volume = volume;
    setAudioElement(audio);

    return () => {
      audio.pause();
      audio.src = '';
      destroyAudioContext();
    };
  }, [currentTrack]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleProgress = (state: { played: number }) => {
    if (!seeking) {
      setProgress(state.played);
    }
  };

  const handleSeekMouseDown = () => {
    setSeeking(true);
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProgress(parseFloat(e.target.value));
  };

  const handleSeekMouseUp = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSeeking(false);
    if (playerRef.current) {
      playerRef.current.seekTo(parseFloat(e.target.value));
    }
  };

  const handlePrevTrack = () => {
    setCurrentTrack(currentTrack === 0 ? tracks.length - 1 : currentTrack - 1);
  };

  const handleNextTrack = () => {
    setCurrentTrack(currentTrack === tracks.length - 1 ? 0 : currentTrack + 1);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (playerRef.current) {
      playerRef.current.player.player.volume = newVolume;
    }
    if (audioElement) {
      audioElement.volume = newVolume;
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (playerRef.current) {
      playerRef.current.player.player.volume = !isMuted ? 0 : volume;
    }
    if (audioElement) {
      audioElement.volume = !isMuted ? 0 : volume;
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {audioElement && !isCollapsed && (
        <AudioVisualizer 
          audioElement={audioElement}
          isPlaying={isPlaying}
          isEnabled={isVisualizerEnabled}
        />
      )}
      
      <div className="bg-light-void border-t border-blue-steel/20 p-4 relative">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="absolute -top-8 right-4 bg-light-void px-4 py-2 rounded-t-lg border-t border-l border-r border-blue-steel/20"
        >
          {isCollapsed ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </button>

        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex gap-2">
              <button 
                onClick={handlePrevTrack}
                className="p-2 hover:bg-dark-void rounded-full transition-colors"
              >
                <SkipBack size={20} />
              </button>
              <button
                onClick={handlePlayPause}
                className="p-2 hover:bg-dark-void rounded-full transition-colors"
              >
                {isPlaying ? <Pause size={24} /> : <Play size={24} />}
              </button>
              <button 
                onClick={handleNextTrack}
                className="p-2 hover:bg-dark-void rounded-full transition-colors"
              >
                <SkipForward size={20} />
              </button>
            </div>
            <div className="flex items-center gap-3">
              <img 
                src={tracks[currentTrack].cover} 
                alt={tracks[currentTrack].title}
                className="w-12 h-12 rounded-lg object-cover shadow-lg hover:scale-105 transition-transform duration-300"
              />
              <div>
                <p className="font-medium">{tracks[currentTrack].title}</p>
                <p className="text-sm text-blue-steel">{tracks[currentTrack].artist}</p>
              </div>
            </div>
          </div>

          <div className="flex-1 mx-8">
            <input
              type="range"
              min={0}
              max={1}
              step="any"
              value={progress}
              onMouseDown={handleSeekMouseDown}
              onChange={handleSeekChange}
              onMouseUp={handleSeekMouseUp}
              className="w-full h-1 bg-blue-steel/20 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-steel"
            />
          </div>

          <ReactPlayer
            ref={playerRef}
            url={tracks[currentTrack].audioUrl}
            playing={isPlaying}
            volume={isMuted ? 0 : volume}
            width="0"
            height="0"
            onProgress={handleProgress}
            onEnded={handleNextTrack}
          />

          <div className="flex items-center gap-4">
            <button
              onClick={toggleMute}
              className="hover:text-blue-steel transition-colors"
            >
              {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-24 h-1 bg-blue-steel/20 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-steel"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;