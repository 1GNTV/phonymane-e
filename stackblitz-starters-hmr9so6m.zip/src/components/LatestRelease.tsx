import React from 'react';
import { Link } from 'react-router-dom';
import { tracks } from '../data/tracks';

const LatestRelease = () => {
  const latestTrack = tracks[0];

  return (
    <section className="py-20 px-4 md:px-8 bg-dark-void">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-2xl font-semibold mb-8 text-blue-steel">Latest Release</h2>
        <Link to="/release" className="inline-block group">
          <div className="relative w-64 h-64 md:w-80 md:h-80 mx-auto mb-6">
            <img 
              src={latestTrack.cover}
              alt={latestTrack.title}
              className="w-full h-full object-cover rounded-lg shadow-2xl group-hover:scale-105 transition-transform duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-end justify-center pb-4">
              <span className="text-white font-medium">View Release</span>
            </div>
          </div>
          <h3 className="text-2xl font-bold mb-2">{latestTrack.title}</h3>
          <p className="text-blue-steel">{latestTrack.artist}</p>
        </Link>
      </div>
    </section>
  );
};

export default LatestRelease;