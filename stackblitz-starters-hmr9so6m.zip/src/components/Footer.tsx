import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Youtube, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-light-void py-12 px-4 md:px-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <h3 className="text-2xl font-bold mb-4">PHONYMANE</h3>
          <p className="text-blue-steel">Just another artist having fun !</p>
        </div>

        <div>
          <h4 className="font-semibold mb-4">Quick Links</h4>
          <ul className="space-y-2 text-blue-steel">
            <li>
              <Link to="/" className="inline-block hover:text-white transition-colors py-1">
                Home
              </Link>
            </li>
            <li>
              <Link to="/contact" className="inline-block hover:text-white transition-colors py-1">
                Contact
              </Link>
            </li>
            <li>
              <Link to="/release" className="inline-block hover:text-white transition-colors py-1">
                Latest Release
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-4">Contact</h4>
          <ul className="space-y-2 text-blue-steel">
            <li>
              <a 
                href="mailto:contact@phonymane.fr" 
                className="inline-flex items-center gap-2 hover:text-white transition-colors py-1"
              >
                <Mail size={16} />
                contact@phonymane.fr
              </a>
            </li>
            <li className="flex items-center gap-2">
              <MapPin size={16} />
              <span>Paris, France</span>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-4">Follow me !</h4>
          <div className="flex gap-4">
            <a 
              href="https://instagram.com/phonymane_" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 hover:text-blue-steel transition-colors"
            >
              <Instagram size={24} />
            </a>
            <a 
              href="https://youtube.com/@phonymane" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 hover:text-blue-steel transition-colors"
            >
              <Youtube size={24} />
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-8 pt-8 border-t border-blue-steel/20">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-blue-steel">
          <p>© {currentYear} PHONYMANE. All rights reserved.</p>
          <div className="flex gap-8">
            <Link to="/release" className="inline-block hover:text-white transition-colors py-1">
              Latest Release
            </Link>
            <a href="#" className="inline-block hover:text-white transition-colors py-1">
              Privacy Policy
            </a>
            <a href="#" className="inline-block hover:text-white transition-colors py-1">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;