import React from 'react';

interface IconProps {
  size?: number;
}

export const SoundCloudIcon: React.FC<IconProps> = ({ size = 24 }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="currentColor"
    width={size}
    height={size}
  >
    <path d="M11.56 2.5c-2.805 0-5.255 1.515-6.56 3.765C2.175 6.615 0 8.94 0 11.755c0 2.94 2.385 5.325 5.325 5.325h6.235c3.525 0 6.385-2.86 6.385-6.385 0-3.525-2.86-6.385-6.385-6.385zM5.325 15.58c-2.115 0-3.825-1.71-3.825-3.825 0-2.115 1.71-3.825 3.825-3.825.285 0 .57.03.84.105C6.75 5.95 8.97 4.5 11.56 4.5c3.075 0 5.565 2.49 5.565 5.565 0 3.075-2.49 5.565-5.565 5.565H5.325z"/>
  </svg>
);