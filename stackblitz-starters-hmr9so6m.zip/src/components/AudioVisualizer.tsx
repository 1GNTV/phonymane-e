import React, { useEffect, useRef } from 'react';
import { createAudioContext, destroyAudioContext, getAudioData } from '../utils/audioContext';
import { drawVisualization } from '../utils/visualizer';

interface AudioVisualizerProps {
  audioElement: HTMLMediaElement;
  isPlaying: boolean;
  isEnabled: boolean;
}

const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ audioElement, isPlaying, isEnabled }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();

  // Initialize audio context
  useEffect(() => {
    if (!isEnabled) return;
    
    const audioContext = createAudioContext(audioElement);
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      destroyAudioContext();
    };
  }, [audioElement, isEnabled]);

  // Handle animation
  useEffect(() => {
    if (!isEnabled || !isPlaying) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      return;
    }

    const animate = () => {
      const data = getAudioData(canvasRef);
      if (data) {
        drawVisualization(data);
      }
      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, isEnabled]);

  if (!isEnabled) return null;

  return (
    <canvas
      ref={canvasRef}
      className="absolute bottom-full left-0 right-0 w-full h-24 opacity-50"
      width={window.innerWidth}
      height={96}
    />
  );
};

export default AudioVisualizer;