import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';

interface HeroProps {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
}

const Hero = ({ isPlaying, setIsPlaying }: HeroProps) => {
  const navigate = useNavigate();

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-20"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-dark-void"></div>
      <div className="relative z-10 text-center px-4">
        <h1 className="text-6xl md:text-8xl font-bold mb-6 tracking-tighter">PHONYMANE</h1>
        <p className="text-blue-steel text-xl md:text-2xl mb-8">your average artist</p>
        <button 
          onClick={() => navigate('/release')}
          className="inline-block bg-white text-dark-void hover:bg-blue-steel transition-colors rounded-full group"
        >
          <div className="px-8 py-3 flex items-center justify-center gap-2">
            <ExternalLink size={20} className="transition-transform group-hover:scale-105" />
            <span>Upcoming Release</span>
          </div>
        </button>
      </div>
    </section>
  );
};

export default Hero;