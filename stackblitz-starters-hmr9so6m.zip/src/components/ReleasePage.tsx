import React, { useState, useEffect } from 'react';
import { Calendar, Clock, ExternalLink, Youtube } from 'lucide-react';
import { SpotifyIcon } from './icons/SpotifyIcon';
import { SoundCloudIcon } from './icons/SoundCloudIcon';
import { AppleMusicIcon } from './icons/AppleMusicIcon';
import { formatCountdown } from '../utils/time';

const ReleasePage = () => {
  const releaseDate = new Date('2024-12-20T00:00:00');
  const [countdown, setCountdown] = useState(formatCountdown(releaseDate));

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(formatCountdown(releaseDate));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-void to-light-void pt-20">
      <div className="max-w-4xl mx-auto px-4 py-20">
        <div className="relative">
          {/* Pre-save badge */}
          <div className="absolute -top-4 -right-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-2 rounded-full transform rotate-12 z-10 animate-pulse">
            Pre-save Now
          </div>

          {/* Main content card */}
          <div className="bg-light-void rounded-2xl p-8 md:p-12 shadow-2xl relative overflow-hidden backdrop-blur-sm">
            {/* Background gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10"></div>

            <div className="relative z-10">
              {/* Release info */}
              <div className="flex flex-col md:flex-row gap-8 items-center mb-12">
                <div className="relative group">
                  <img 
                    src="https://valtis.wtf/fullthrottle/assets/images/cover.jpg"
                    alt="FULL THROTTLE Cover Art" 
                    className="w-64 h-64 md:w-80 md:h-80 rounded-lg shadow-2xl transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-end justify-center pb-4">
                    <span className="text-white font-medium">Coming Soon</span>
                  </div>
                </div>
                
                <div className="text-center md:text-left">
                  <div className="inline-block bg-blue-steel/20 text-blue-steel px-4 py-1 rounded-full mb-4">
                    Upcoming Release
                  </div>
                  <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                    FULL THROTTLE
                  </h1>
                  <p className="text-xl md:text-2xl text-blue-steel mb-6">valtis, PHONYMANE</p>
                  
                  <div className="flex flex-wrap gap-4 justify-center md:justify-start mb-6">
                    <div className="flex items-center gap-2 bg-blue-steel/20 px-4 py-2 rounded-lg">
                      <Calendar size={20} className="text-blue-steel" />
                      <span>December 20, 2024</span>
                    </div>
                  </div>

                  {/* Countdown */}
                  <div className="grid grid-cols-4 gap-4 bg-dark-void p-4 rounded-lg mb-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{countdown.days}</div>
                      <div className="text-sm text-blue-steel">Days</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{countdown.hours}</div>
                      <div className="text-sm text-blue-steel">Hours</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{countdown.minutes}</div>
                      <div className="text-sm text-blue-steel">Minutes</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-white">{countdown.seconds}</div>
                      <div className="text-sm text-blue-steel">Seconds</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Pre-save buttons */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <button className="flex items-center justify-center gap-2 bg-[#1DB954] hover:bg-[#1ed760] text-white px-6 py-4 rounded-lg transition-all duration-300 hover:scale-105">
                  <SpotifyIcon size={24} />
                  <span>Pre-save on Spotify</span>
                </button>
                <button className="flex items-center justify-center gap-2 bg-[#FF5500] hover:bg-[#ff7733] text-white px-6 py-4 rounded-lg transition-all duration-300 hover:scale-105">
                  <SoundCloudIcon size={24} />
                  <span>Pre-save on SoundCloud</span>
                </button>
                <button className="flex items-center justify-center gap-2 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white px-6 py-4 rounded-lg transition-all duration-300 hover:scale-105">
                  <AppleMusicIcon size={24} />
                  <span>Pre-add on Apple Music</span>
                </button>
                <button className="flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white px-6 py-4 rounded-lg transition-all duration-300 hover:scale-105">
                  <Youtube size={24} />
                  <span>Subscribe on YouTube</span>
                </button>
              </div>

              {/* Description */}
              <div className="mt-12 p-6 bg-dark-void rounded-lg backdrop-blur-sm">
                <h2 className="text-xl font-semibold mb-4">About the Release</h2>
                <p className="text-blue-steel">
                  Get ready for a fire collaboration between valtis and PHONYMANE. 
                  FULL THROTTLE is an ep with a total of 4 songs : CORNER SHOP, TRACTIONLESS, GRIP and FRAYSER. Be ready!
                </p>
              </div>

              {/* Back button */}
              <div className="mt-8 text-center">
                <button 
                  onClick={() => window.history.back()} 
                  className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 rounded-full hover:bg-blue-700 transition-all duration-300 hover:scale-105"
                >
                  <ExternalLink size={20} />
                  Back to Home
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReleasePage;