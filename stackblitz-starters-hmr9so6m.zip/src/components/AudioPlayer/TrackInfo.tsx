import React from 'react';
import { Track } from '../../types/track';

interface TrackInfoProps {
  track: Track;
}

const TrackInfo: React.FC<TrackInfoProps> = ({ track }) => {
  return (
    <div className="flex items-center gap-3">
      <img 
        src={track.cover} 
        alt={track.title}
        className="w-12 h-12 rounded-lg object-cover shadow-lg hover:scale-105 transition-transform duration-300"
      />
      <div>
        <p className="font-medium">{track.title}</p>
        <p className="text-sm text-blue-steel">{track.artist}</p>
      </div>
    </div>
  );
};

export default TrackInfo;