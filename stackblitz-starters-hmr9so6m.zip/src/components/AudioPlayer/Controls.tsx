import React from 'react';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react';

interface ControlsProps {
  isPlaying: boolean;
  onPlayPause: () => void;
  onPrev: () => void;
  onNext: () => void;
}

const Controls: React.FC<ControlsProps> = ({
  isPlaying,
  onPlayPause,
  onPrev,
  onNext
}) => {
  return (
    <div className="flex gap-2">
      <button 
        onClick={onPrev}
        className="p-2 hover:bg-dark-void rounded-full transition-colors"
      >
        <SkipBack size={20} />
      </button>
      <button
        onClick={onPlayPause}
        className="p-2 hover:bg-dark-void rounded-full transition-colors"
      >
        {isPlaying ? <Pause size={24} /> : <Play size={24} />}
      </button>
      <button 
        onClick={onNext}
        className="p-2 hover:bg-dark-void rounded-full transition-colors"
      >
        <SkipForward size={20} />
      </button>
    </div>
  );
};

export default Controls;