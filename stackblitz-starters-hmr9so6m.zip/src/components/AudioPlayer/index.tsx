import React from 'react';
import ReactPlayer from 'react-player';
import { tracks } from '../../data/tracks';
import AudioVisualizer from '../AudioVisualizer';
import { useAudioPlayer } from '../../hooks/useAudioPlayer';
import Controls from './Controls';
import TrackInfo from './TrackInfo';
import VolumeControl from './VolumeControl';
import ProgressBar from './ProgressBar';

interface AudioPlayerProps {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  currentTrack: number;
  setCurrentTrack: (track: number) => void;
  isVisualizerEnabled: boolean;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ 
  isPlaying, 
  setIsPlaying, 
  currentTrack, 
  setCurrentTrack,
  isVisualizerEnabled
}) => {
  const {
    playerRef,
    audioElement,
    volume,
    isMuted,
    progress,
    handleProgress,
    handleSeek,
    handleTrackChange,
    handleVolume
  } = useAudioPlayer(currentTrack, tracks, isPlaying, setCurrentTrack);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {audioElement && isVisualizerEnabled && (
        <AudioVisualizer 
          audioElement={audioElement}
          isPlaying={isPlaying}
          isEnabled={isVisualizerEnabled}
        />
      )}
      
      <div className="bg-light-void border-t border-blue-steel/20 p-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row gap-4 md:gap-0 md:items-center justify-between">
          <div className="flex items-center gap-4">
            <Controls
              isPlaying={isPlaying}
              onPlayPause={() => setIsPlaying(!isPlaying)}
              onPrev={handleTrackChange.prev}
              onNext={handleTrackChange.next}
            />
            <TrackInfo track={tracks[currentTrack]} />
          </div>

          <div className="flex-1 mx-0 md:mx-8">
            <ProgressBar
              progress={progress}
              onMouseDown={handleSeek.onMouseDown}
              onChange={handleSeek.onChange}
              onMouseUp={handleSeek.onMouseUp}
            />
          </div>

          <ReactPlayer
            ref={playerRef}
            url={tracks[currentTrack].audioUrl}
            playing={isPlaying}
            volume={isMuted ? 0 : volume}
            width="0"
            height="0"
            onProgress={handleProgress}
            onEnded={handleTrackChange.next}
          />

          <div className="hidden md:flex">
            <VolumeControl
              volume={volume}
              isMuted={isMuted}
              onVolumeChange={handleVolume.change}
              onToggleMute={handleVolume.toggleMute}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;