import React from 'react';

interface ProgressBarProps {
  progress: number;
  onMouseDown: () => void;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onMouseUp: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  onMouseDown,
  onChange,
  onMouseUp
}) => {
  return (
    <div className="flex-1 mx-8">
      <input
        type="range"
        min={0}
        max={1}
        step="any"
        value={progress}
        onMouseDown={onMouseDown}
        onChange={onChange}
        onMouseUp={onMouseUp}
        className="w-full h-1 bg-blue-steel/20 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-steel"
      />
    </div>
  );
};

export default ProgressBar;