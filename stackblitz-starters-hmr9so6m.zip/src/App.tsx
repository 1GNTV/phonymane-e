import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Releases from './components/Releases';
import Shows from './components/Shows';
import Footer from './components/Footer';
import AudioPlayer from './components/AudioPlayer';
import ReleasePage from './components/ReleasePage';
import ContactPage from './components/ContactPage';
import BiographyPage from './components/BiographyPage';
import Linktree from './components/Linktree';
import Products from './components/Products';
import Wiki from './components/Wiki/Wiki';

const App: React.FC = () => {
  const [isPlaying, setIsPlaying] = React.useState(false);
  const [currentTrack, setCurrentTrack] = React.useState(0);
  const [isLinktreeOpen, setIsLinktreeOpen] = React.useState(true);
  const [isVisualizerEnabled] = React.useState(true);

  React.useEffect(() => {
    const state = window.history.state;
    if (state && state.scrollTo) {
      const element = document.getElementById(state.scrollTo);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-dark-void text-white">
        <Navbar onLinktreeOpen={() => setIsLinktreeOpen(true)} />
        <Routes>
          <Route path="/" element={
            <>
              <Hero isPlaying={isPlaying} setIsPlaying={setIsPlaying} />
              <Shows />
              <Releases 
                setIsPlaying={setIsPlaying}
                setCurrentTrack={setCurrentTrack}
              />
              <Products />
            </>
          } />
          <Route path="/release" element={<ReleasePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/biography" element={<BiographyPage />} />
          <Route path="/wiki/*" element={<Wiki />} />
        </Routes>
        <Footer />
        <AudioPlayer 
          isPlaying={isPlaying} 
          setIsPlaying={setIsPlaying} 
          currentTrack={currentTrack}
          setCurrentTrack={setCurrentTrack}
          isVisualizerEnabled={isVisualizerEnabled}
        />
        <Linktree 
          isOpen={isLinktreeOpen} 
          onClose={() => setIsLinktreeOpen(false)} 
        />
      </div>
    </Router>
  );
}

export default App;